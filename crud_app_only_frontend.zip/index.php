<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css" type="text/css">
    <title>PHP CRUD</title>
</head>
<body>
    <div class="main">
<!-- FORM AREA STARTS HERE -->
    <div class="form">
    <form>
    <input type="text" class="input" placeholder="First name...">
    <input type="text" class="input" placeholder="Last name...">
    <input type="email" class="input long-input" placeholder="Email id...">
    <input type="submit" class="long-input add-button" value="ADD TO DATABASE">
    </form>
    </div>
<!-- FORM AREA ENDS HERE -->
  
<!-- DATABASE RECORDS AREA STARTS HERE -->
<div class="record">

<p class="warn">No Data Available</p>

<div class="record-item">
    <h1>Mohan Goswami</h1>
    <p>workwithmohan@gmail.com</p>
    <button class="menu-btn edit-btn">Edit</button>
    <button class="menu-btn delete-btn">Delete</button>
</div> 

</div>
<!-- DATABASE RECORDS AREA ENDS HERE -->
   
</div>
</body>
</html>