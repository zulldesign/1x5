<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Upload Images</title>
</head>
<body>
    
    <div class="topbar">
     <div class="topbar_frame">   
    <h2>
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-images" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M12.002 4h-10a1 1 0 0 0-1 1v8l2.646-2.354a.5.5 0 0 1 .63-.062l2.66 1.773 3.71-3.71a.5.5 0 0 1 .577-.094l1.777 1.947V5a1 1 0 0 0-1-1zm-10-1a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-10zm4 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
  <path fill-rule="evenodd" d="M4 2h10a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1v1a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2h1a1 1 0 0 1 1-1z"/>
</svg> Image Gallery</h2>
<a href="index.php">
<button class="upload-btn">My Photos</button></a>

     </div>
    </div>
    <div class="gallery-fix">
    <div class="gallery" style="width:500px;padding:20px">
        <form enctype="multipart/form-data" method="post" action="upload.php">
            <input type="file" name="img[]" multiple>
            <input type="submit" name="upload" class="blue-btn" value="Upload Photos">
        </form>

    </div>
    </div>
    <script src="logic.js"></script>
    
</body>
</html>