<?php
$db = mysqli_connect('localhost','root','','mygallery') or die("Database is not connected");
?>