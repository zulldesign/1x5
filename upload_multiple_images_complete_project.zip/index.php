<?php
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Image Gallery</title>
</head>
<body>
    <div class="img-view" style="display: none;">
<div class="img-file">
    <img src="images/pic (1).jpg" class="image"><br>
    <center>
    <button class="blue-btn" id="close">Close</button>
    <button class="red-btn">Delete</button>
    </center>
</div>
    </div>
    <div class="topbar">
     <div class="topbar_frame">   
    <h2>
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-images" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M12.002 4h-10a1 1 0 0 0-1 1v8l2.646-2.354a.5.5 0 0 1 .63-.062l2.66 1.773 3.71-3.71a.5.5 0 0 1 .577-.094l1.777 1.947V5a1 1 0 0 0-1-1zm-10-1a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-10zm4 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
  <path fill-rule="evenodd" d="M4 2h10a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1v1a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2h1a1 1 0 0 1 1-1z"/>
</svg> Image Gallery</h2>
<a href="uploadimage.php">
<button class="upload-btn"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/>
</svg> Upload Photos</button></a>

     </div>
    </div>
    <div class="gallery-fix">
    <div class="gallery">
<?php
$query = "SELECT * FROM images";
$run = mysqli_query($db,$query);
while($data = mysqli_fetch_array($run)){
  ?>
  <div class="img" onclick="view('images/<?=$data['url']?>')" style="background-image: url('images/<?=$data['url']?>');">
      </div>
  <?php
  
}
?>

      
        
        


    </div>
    </div>
    <script src="logic.js"></script>
    
</body>
</html>