<?php
include('db.php');

if(isset($_POST['upload'])){
    
$img_count =  count($_FILES['img']['name']);

for($i=0;$i<$img_count;$i++){
    $img_name =  time().$_FILES['img']['name'][$i];
    $img_temp =  $_FILES['img']['tmp_name'][$i];
    if(move_uploaded_file($img_temp,"images/$img_name")){
        $query = "INSERT INTO images (url) VALUES('$img_name')";
    $run = mysqli_query($db,$query);
    if($run){
        echo "<script>window.location.href='index.php';</script>";
    }else{
        echo "data not added";
    }
    }

    

}
}
?>
