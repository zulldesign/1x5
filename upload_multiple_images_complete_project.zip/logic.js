var viewimage = document.getElementsByClassName("img-view")[0];
var image = document.getElementsByClassName("image")[0];

function view(img){
    viewimage.setAttribute("style","display:");
    image.setAttribute("src",img);
    
    
}

var closebtn = document.getElementById("close");
closebtn.addEventListener("click",function(){
    viewimage.setAttribute("style","display:none");

});
