<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Login</title>
</head>
<body>
  <div class="main">
      <div class="login-box">
          <h1>Login</h1>
          <form>
              <input type="text" placeholder="Enter Email Id..." class="input">
              <input type="password" placeholder="Enter Password..." class="input">
              <div class="row">
              <a href="register.php" class="register-btn">Create Account</a><input type="submit" value="Login" class="login-btn">
              </div>

          </form>
      </div>
  </div>  
</body>
</html>