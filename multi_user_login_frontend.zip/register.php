<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Register</title>
</head>
<body>
  <div class="main">
      <div class="login-box">
          <h1>Register</h1>
          <form>
            <input type="text" placeholder="Enter Full Name..." class="input">

              <input type="text" placeholder="Enter Email Id..." class="input">
              <input type="password" placeholder="Enter Password..." class="input">
              <div class="row">
              <a href="index.php" class="register-btn">Login</a><input type="submit" value="Register" class="login-btn">
              </div>

          </form>
      </div>
  </div>  
</body>
</html>