<?php
$db = mysqli_connect('localhost','root','','crud_app') or die("Database is not connected !");
?>