<?php
$db = mysqli_connect('localhost','root','','refwebsite') or die('Database is not connected !');