<?php
$db=mysqli_connect("localhost","root","","offlinewallet") or die("database is not connected");