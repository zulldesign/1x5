<?php
$db = mysqli_connect('localhost', 'root', '', 'dchat') or die("Database Not Connected !");
