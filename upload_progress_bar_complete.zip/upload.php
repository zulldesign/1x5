<?php
$filename=time().$_FILES['myfile']['name'];
$tmp=$_FILES['myfile']['tmp_name'];
move_uploaded_file($tmp,"uploads/$filename");
?>