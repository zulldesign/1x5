<?php
session_start();
$db = mysqli_connect('localhost','root','','loginsignup') or die("database is not connected");
error_reporting(0);
?>