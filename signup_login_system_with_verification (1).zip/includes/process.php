<?php
session_start();
require('functions.php');
require('sendmail.php');



if(isset($_POST['signup'])){
    if(checkSignUpInput($_POST)){
if(!checkDuplicateEmail($_POST)){
if(createNewAccount($_POST)){
    $_SESSION['msg']='Account is Created, Login to verify you email';
    $ver_data=genVerificationCode();
   $data['email_id']=$_POST['email_id'];
   $data['code']=$ver_data['code'];
   $data['url']=$ver_data['url'];
   $data['mail']=$mail;
   $data['id']=getUserIdByEmailId($_POST);
   sendVerification($data);
addVerificationStatus($data);
   
    $_SESSION['done']=true;

}else{
    $_SESSION['msg']='Something is wrong, try again';
}
}else{
    $_SESSION['msg']='Email Id is Already registered';

}
    }else{
    $_SESSION['msg']='All Input Fields are Required !';
        
    }
if(isset($_SESSION['done'])){
    header('location:../?login');
}else{
    header('location:../?signup');

}
}



if(isset($_POST['login'])){
    if(checkLoginInput($_POST)){
if(checkUser($_POST)){
$_SESSION['userdata']=getUserDetailByEmailId($_POST);
$_SESSION['auth']=true;

}else{
    $_SESSION['msg']='Incorrect Email Id/Password';

}
    }else{
    $_SESSION['msg']='All Input Fields are Required !';
        
    }
    header('location:../?login');

}

if(isset($_GET['logout'])){
    session_destroy();
    session_start();
    $_SESSION['msg']='User Logged Out !';

    header('location:../');
}

if(isset($_GET['verify'])){
    $data['code']=$_POST['code'];
    $data['id']=$_SESSION['userdata']['id'];
   
if(verifyCode($data)){
updateStatus($data);
}else{
    $_SESSION['msg']='Your verification code is incorrect';

}
header('location:../');

}