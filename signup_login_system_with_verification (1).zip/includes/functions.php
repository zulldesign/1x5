<?php
require('database.php');

function checkDuplicateEmail($data){
    $db = $GLOBALS['db'];
    $email_id=mysqli_real_escape_string($db,$data['email_id']); 

    $query="SELECT COUNT(*) FROM users WHERE email_id='$email_id'";
    $run=mysqli_query($db,$query);
    $user=mysqli_fetch_array($run);
    return $user[0];
}

function checkSignUpInput($data){
    if($data['full_name']=='' && $data['email_id']=='' && $data['password']==''){
return false;
    }

    return true;
    
}
function checkLoginInput($data){
    if($data['email_id']=='' && $data['password']==''){
return false;
    }

    return true;
    
}
 
function createNewAccount($data){
    $db = $GLOBALS['db'];
    $email_id=mysqli_real_escape_string($db,$data['email_id']); 
    $full_name=mysqli_real_escape_string($db,$data['full_name']);
    $password=mysqli_real_escape_string($db,$data['password']);

    $query="INSERT INTO users (full_name,email_id,password) ";
    $query.=" VALUES('$full_name','$email_id','$password')";
    $run=mysqli_query($db,$query);
    return $run;
}


function checkUser($data){
    $db = $GLOBALS['db'];
    $password=mysqli_real_escape_string($db,$data['password']);
    $email_id=mysqli_real_escape_string($db,$data['email_id']); 
    $query="SELECT COUNT(*) FROM users WHERE email_id='$email_id' && password='$password'";
    $run=mysqli_query($db,$query);
    $user=mysqli_fetch_array($run);
    return $user[0];
}

function getUserDetailByEmailId($data){
    $db = $GLOBALS['db'];
    $email_id=mysqli_real_escape_string($db,$data['email_id']); 
    $query="SELECT * FROM users WHERE email_id='$email_id'";
    $run=mysqli_query($db,$query);
    $user=mysqli_fetch_array($run);
    return $user;
}
function getUserIdByEmailId($data){
    $db = $GLOBALS['db'];
    $email_id=mysqli_real_escape_string($db,$data['email_id']); 
    $query="SELECT id FROM users WHERE email_id='$email_id'";
    $run=mysqli_query($db,$query);
    $user=mysqli_fetch_array($run);
    return $user['id'];
}

function genVerificationCode(){
    $url='http://localhost/signup_login_system_with_verification/?verify=';
    $random_string='';
    $code=rand(111111,999999);
$string='abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVCBZNSGWG'.time();
$string = str_shuffle($string);
$string = str_split($string,1);

for($i=0;$i<30;$i++){
    $random_string.=$string[$i];
}

$url.=$random_string;
return ["url"=>$url,"code"=>$code];

}

function addVerificationStatus($data){
    $db = $GLOBALS['db'];
    $id=$data['id'];
    $code=$data['code'];
    $link=$data['url']; 
  

    $query="INSERT INTO email_verification (user_id,code,link,status) ";
    $query.=" VALUES($id,'$code','$link','pending')";
    $run=mysqli_query($db,$query);
    return $run;
}

function getUserStatus($data){
    $db = $GLOBALS['db'];
$id=$data['id']; 
    $query="SELECT * FROM email_verification WHERE user_id=$id";
    $run=mysqli_query($db,$query);
    $user=mysqli_fetch_array($run);
    return $user['status']; 
}

function verifyCode($data){
    $db = $GLOBALS['db'];
    $id=$data['id'];
    $code=$data['code'];  
    $query="SELECT count(*) FROM email_verification WHERE user_id=$id && code='$code'";
    $run=mysqli_query($db,$query);
    $user = mysqli_fetch_array($run);
    return $user[0];
}

function verifyUrl($data){
    $db = $GLOBALS['db'];
    $url=$data['url'];  
    $query="SELECT count(*) FROM email_verification WHERE link='$url' && status='pending'";
    $run=mysqli_query($db,$query);
    $user = mysqli_fetch_array($run);
    return $user[0];
}

function updateStatus($data){
    $db = $GLOBALS['db'];
    $id=$data['id'];
    $query="UPDATE email_verification SET status='verfied' WHERE user_id=$id";
    $run=mysqli_query($db,$query);
  

   return $run;
}

function updateStatusByUrl($data){
    $db = $GLOBALS['db'];
    $url=$data['url'];
    $query="UPDATE email_verification SET status='verfied' WHERE link='$url'";
    $run=mysqli_query($db,$query);
  

   return $run;
}
