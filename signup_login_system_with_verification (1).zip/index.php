<?php
session_start();
include('includes/functions.php');

if(isset($_GET['verify'])){
    $url="http://localhost/signup_login_system_with_verification/?verify=".$_GET['verify'];
    $data['url']=$url;

    if(verifyUrl($data)){
  updateStatusByUrl($data);
    
   header('location:?home');
    }else{
        echo "invalid verification code or email id is already verified";
    
    }
    }elseif(isset($_SESSION['auth'])){
    $user=$_SESSION['userdata'];
    if(getUserStatus($user)=='pending'){
        include('pages/verification.php');

    }else{
        include('pages/home.php');

    }
}elseif(isset($_GET['login'])){
    include('pages/login.php');
}elseif(isset($_GET['signup'])){
    include('pages/signup.php');
}else{
    include('pages/login.php');

}

