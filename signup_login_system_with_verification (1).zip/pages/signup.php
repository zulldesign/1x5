<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Signup</title>
</head>
<body>
<nav class="navbar navbar-dark bg-danger">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="../images/icon.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      DevNinja
    </a>
  </div>
</nav>
<div class="container">
    <div class="col-7 m-auto mt-5 shadow p-5 border-info rounded">
        <h1>Sign Up</h1>
        <br>
        <?php
if(isset($_SESSION['msg'])){
  echo '<p class="text-danger">'.$_SESSION['msg'].'</p>';
  unset($_SESSION['msg']);
}
        ?>
        
    <form method="post" action="includes/process.php">
      <input type="hidden" name="signup" value="true">
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Full Name</label>
    <input type="text" name="full_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" name="email_id" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1">
  </div>
<div class="d-flex justify-content-between">
  <button type="submit" class="btn btn-danger">Sign Up</button>
  <a href="?login" class="text-decoration-none text-danger">Already have an account?</a>
</div>
</form>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
</body>
</html>