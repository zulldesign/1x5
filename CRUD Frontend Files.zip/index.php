
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>

<body style="background-color:#ddf0ff">
    <nav class="navbar bg-body-tertiary shadow-sm border-bottom">
        <div class="container-fluid d-flex justify-content-center">
            <a class="navbar-brand" href="#">
                <img src="php.png" alt="Logo" height="24"
                    class="d-inline-block align-text-top">
                CRUD Operations
            </a>
        </div>
    </nav>

    <div class="container">

<div class="card my-3">
            <div class="card-header">
                Add Students
            </div>
            <div class="card-body">
                <form class="row g-3">
                    <div class="col-md-6">
                        <label for="inputEmail4" class="form-label">Profile Pic</label>
                        <input type="file" class="form-control" id="inputEmail4">
                    </div>
                    <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Full Name</label>
                        <input type="text" class="form-control" placeholder="enter student full name"
                            id="inputPassword4">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Date Of Birth</label>
                        <input type="date" class="form-control">
                </div>

                    <div class="col-md-6">
                        <label class="form-label">Email Id</label>
                        <input type="email" placeholder="enter student email id" class="form-control">
                    </div>


                    <div class="col-12 text-end">
                        <button type="submit" class="btn btn-primary">Add To Database</button>
                    </div>
                </form>
            </div>
        </div>

    


        <div class="card my-3">
            <div class="card-header">
                Student Lists
            </div>
            <div class="card-body d-flex flex-wrap">
               
                <div class="col-12">
                 
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="enter student name..."
                            aria-label="student name"  aria-describedby="basic-addon2" required>
                        <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2"><i class="bi bi-search"></i>
                            Search</button>
                    </div>

                </div>
                
              

 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->

                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
                 <!-- //student start -->
                <div class="col-12 col-md-6 col-lg-4 p-2">
                    <div class="d-flex gap-3 align-items-start border rounded shadow-sm p-2">
                        <img src="https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg" height="85px" width="85px"
                            class="rounded" />

                        <div class="">
                            <div class="small">Monu Kumar Giri</div>
                            <div class="small"><i class="bi bi-envelope"></i> whomonugiri@gmail.com</div>
                            <div class="small"><i class="bi bi-cake"></i> 14 July,1999</div>
                            <div><a href="#" class="text-decoration-none small"><i class="bi bi-pencil-square"></i>
                                    Edit</a>
                                <a href="#" class="text-decoration-none text-danger small"><i class="bi bi-trash"></i>
                                    Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- //student end -->
   
                





            </div>
            <hr>
            <div class="d-flex justify-content-between p-3">
                <button  class="btn btn-dark btn-sm" ><i class="bi bi-arrow-left-circle"></i> Previous</button>
                <div>Page 1/1</div>
                <button   class="btn btn-dark btn-sm " > Next <i class="bi bi-arrow-right-circle"></i></button>
            </div>
        </div>
    </div>
</body>

</html>